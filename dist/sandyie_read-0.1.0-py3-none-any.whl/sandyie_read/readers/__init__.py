from .ocr_reader import read_ocr
