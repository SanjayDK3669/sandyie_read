from .core import read
